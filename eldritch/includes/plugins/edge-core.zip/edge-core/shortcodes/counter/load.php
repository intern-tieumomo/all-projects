<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/counter/counter.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/counter/custom-styles/counter.php';
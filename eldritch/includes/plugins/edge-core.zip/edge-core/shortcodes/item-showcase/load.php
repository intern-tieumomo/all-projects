<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/item-showcase/item-showcase.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/item-showcase/item-showcase-item.php';

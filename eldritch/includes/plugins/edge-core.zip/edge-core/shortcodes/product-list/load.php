<?php
if (eldritch_edge_is_woocommerce_installed()) {
	include_once EDGE_CORE_ABS_PATH . '/shortcodes/product-list/product-list.php';
}
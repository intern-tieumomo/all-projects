<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/highlight/highlight.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/highlight/custom-styles/highlight.php';
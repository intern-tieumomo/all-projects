<?php

require_once EDGE_CORE_ABS_PATH.'/shortcodes/framed-banner/framed-banner.php';
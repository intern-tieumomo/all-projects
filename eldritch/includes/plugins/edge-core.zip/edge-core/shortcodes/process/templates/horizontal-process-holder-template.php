<div <?php eldritch_edge_class_attribute($holder_classes); ?>>
	<div class="edgt-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
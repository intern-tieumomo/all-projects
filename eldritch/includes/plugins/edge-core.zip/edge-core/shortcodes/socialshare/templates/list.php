<div class="edgt-social-share-holder edgt-list">
	<ul>
		<?php foreach($networks as $net) {
			echo eldritch_edge_get_module_part($net);
		} ?>
	</ul>
</div>
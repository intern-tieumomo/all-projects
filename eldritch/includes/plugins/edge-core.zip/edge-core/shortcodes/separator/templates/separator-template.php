<div class="edgt-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div <?php eldritch_edge_class_attribute($separator_inner_class)?> <?php echo eldritch_edge_get_inline_style($separator_style); ?>></div>
</div>

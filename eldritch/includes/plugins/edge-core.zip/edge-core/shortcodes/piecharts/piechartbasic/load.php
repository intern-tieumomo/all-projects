<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/piecharts/piechartbasic/pie-chart-basic.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/piecharts/piechartbasic/custom-styles/pie-chart-basic.php';
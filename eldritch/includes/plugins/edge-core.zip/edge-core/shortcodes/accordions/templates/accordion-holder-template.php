<div class="edgt-accordion-holder clearfix <?php echo esc_attr($acc_class) ?> ">
	<?php echo eldritch_edge_remove_auto_ptag($content) ?>
</div>
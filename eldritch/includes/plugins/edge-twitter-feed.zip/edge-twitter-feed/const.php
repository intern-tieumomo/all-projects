<?php

define('EDGE_TWITTER_FEED_REL_PATH', dirname(plugin_basename(__FILE__)));
<?php

include_once 'const.php';

include_once 'lib/edgt-instagram-api.php';
include_once 'widgets/load.php';